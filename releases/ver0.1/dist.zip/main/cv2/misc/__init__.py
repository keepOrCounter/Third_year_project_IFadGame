from .version import get_ocv_version
