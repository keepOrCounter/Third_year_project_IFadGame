`TO run the game, find and double click the "main.exe" in "main" folder`

This test version contains following contents:

    5 command, move to 4 direction and command to have a rest

    Every move cost some action point, if no action point would reduce player HP

    have a rest could recovery some AP

    different landscape cost different AP